# OfferOnly™ Website Files

Upload these files to your GitHub repository:

- `index.html`
- `style.css`
- `script.js`

Then click **Commit changes**.

If GitHub Pages is turned on, your website will update automatically.

Suggested custom domain later:
- offeronly.com
- offeronlyauto.com
- snapbeforeyouscrap.com
